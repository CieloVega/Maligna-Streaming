#pragma once

class consola{
public:
    void cls();     //Borra la consola
    void pausa();   //Hace una pausa hasta que se presiona <ENTER>
};
